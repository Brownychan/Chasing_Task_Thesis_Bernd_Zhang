// function for getting responses from the UPPS-P questionnaire
var get_resp = function(data, reverse) {
    var resp = data.response.Q0 + 1;// javaScript uses 0-based indexing. Change into 1-based indexing
  
    // reverse coding
    if (reverse === 1) {
      resp = 5 - resp;
    };
  
    return resp;
  
  }
  
  var scale_1 = ["Extremely Unlikekly", "Moderately Unlikely", "Somewhat unlikely", "Not Sure", "Somewhat Likely", "Moderate Likely", "Extremely Likely"];
  
  // questions
  var question_1 = {
    type: jsPsychSurveyLikert,
    questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 1/6:\nBetting a day's income at the horse races./p>",
      labels: scale_1,
      required: true,
    }, ],
    on_finish: function(data) {
      data.task = 'DOSPERT';
      data.question_number = 1;
      data.reverse = 0;
      data.factor = "Financial";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'DOSPERT' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  }
  
  
  var question_2 = {
    type: jsPsychSurveyLikert,
    questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 2/6:\nInvesting 10% of your annual income in a moderate growth mutual fund.</p>",
      labels: scale_1,
      required: true,
    }, ],
    on_finish: function(data) {
      data.task = 'DOSPERT';
      data.question_number = 2;
      data.reverse = 0;
      data.factor = "Financial";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'DOSPERT' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  }
  
  var question_3 = {
    type: jsPsychSurveyLikert,
    questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 3/6:\nBetting a day's income at a high-stake poker game.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'DOSPERT';
      data.question_number = 3;
      data.reverse = 0;
      data.factor = "Financial";
  
      data.resp = get_resp(data, data.reverse);
      
      // write data
      var data_row = data.subjID + ',' + 'DOSPERT' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);  
    }
  };
  
  var question_4 = {
    type: jsPsychSurveyLikert,
    questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 4/6:\nInvesting 5% of your annual income in a very speculative stock.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'DOSPERT';
      data.question_number = 4;
      data.reverse = 0;
      data.factor = "Financial";
  
      data.resp = get_resp(data, data.reverse);
      
      // write data
      var data_row = data.subjID + ',' + 'DOSPERT' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };
  
  var question_5 = {
    type: jsPsychSurveyLikert,
    questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 5/6:\nBetting a day's income on the outcome of a sporting event.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'DOSPERT';
      data.question_number = 5;
      data.reverse = 0;
      data.factor = "Financial";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'DOSPERT' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };
  
  var question_6 = {
    type: jsPsychSurveyLikert,
    questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 6/6:\nInvesting 10% of your annual income in a new business venture.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'DOSPERT';
      data.question_number = 6;
      data.reverse = 0;
      data.factor = "Financial";
  
      data.resp = get_resp(data, data.reverse);
      
      // write data
      var data_row = data.subjID + ',' + 'DOSPERT' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };

  var DOSPERT_Fitems = [question_1, question_2, question_3, question_4, question_5, question_6];
  console.log(DOSPERT_Fitems)
// function for getting responses from the UPPS-P questionnaire
var get_resp = function(data, reverse) {
  var resp = data.response.Q0 + 1;// javaScript uses 0-based indexing. Change into 1-based indexing

  // reverse coding
  if (reverse === 1) {
    resp = 5 - resp;
  };

  return resp;

}

var scale_1 = ["Agree strongly", "Agree some", "Disagree some", "Disagree strongly"];

// questions
var commitment_check = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 1/21:\nI will read the questions carefully before answering them in this survey.</p>",
    labels: scale_1,
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 0;
    data.reverse = 0;
    data.factor = "attention-check";

    data.resp = get_resp(data, data.reverse);
      
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
}


var Question1 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 2/21:\nI usually like to see things through to the end.</p>",
    labels: scale_1,
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 1;
    data.reverse = 0;
    data.factor = "Perseverance";

    data.resp = get_resp(data, data.reverse);
      
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
}

var Question2 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 3/21:\nMy thinking is usually careful and purposeful.</p>",
    labels: scale_1,
    required: true
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 2;
    data.reverse = 0;
    data.factor = "Premeditation";

    data.resp = get_resp(data, data.reverse);
    
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);  
  }
};

var Question3 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 4/21:\nWhen I am in a great mood, I tend to get into situations that could cause me problems.</p>",
    labels: scale_1,
    required: true
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 3;
    data.reverse = 1;
    data.factor = "Positive Urgency";

    data.resp = get_resp(data, data.reverse);
    
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
};

var Question4 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 5/21:\nUnfinished tasks really bother me.</p>",
    labels: scale_1,
    required: true
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 4;
    data.reverse = 0;
    data.factor = "Perseverance";

    data.resp = get_resp(data, data.reverse);
      
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
};

var Question5 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 6/21:\nI like to stop and think things over before I do them.</p>",
    labels: scale_1,
    required: true
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 5;
    data.reverse = 0;
    data.factor = "Premeditation";

    data.resp = get_resp(data, data.reverse);
    
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
};


var Question6 = {
  type: jsPsychSurveyLikert,
    questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 7/21:\nWhen I feel bad, I quite often do things I later regret in order to make myself feel better now.</p>",
    labels: scale_1,
    required: true
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 6;
    data.reverse = 1;
    data.factor = "Negative Urgency";

    data.resp = get_resp(data, data.reverse);
      
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
};


var Question7 = {
  type: jsPsychSurveyLikert,
    questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 8/21:\nOnce I get going on something I hate to stop.</p>",
    labels: scale_1,
    required: true
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 7;
    data.reverse = 0;
    data.factor = "Perseverance";

    data.resp = get_resp(data, data.reverse);
      
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
};

var Question8 = {
  type: jsPsychSurveyLikert,
    questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 9/21:\nSometimes when I feel bad, I can't seem to stop what I am doing even though it is making me feel worse.</p>",
    labels: scale_1,
    required: true
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 8;
    data.reverse = 1;
    data.factor = "Negative Urgency";

    data.resp = get_resp(data, data.reverse);
      
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
};

var Question9 = {
  type: jsPsychSurveyLikert,
    questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 10/21:\nI quite enjoy taking risks.</p>",
    labels: scale_1,
    required: true
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 9;
    data.reverse = 1;
    data.factor = "Sensation Seeking";

    data.resp = get_resp(data, data.reverse);
      
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
};

var Question10 = {
  type: jsPsychSurveyLikert,
    questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 11/21:\nI tend to lose control when I am in a great mood.</p>",
    labels: scale_1,
    required: true
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 10;
    data.reverse = 1;
    data.factor = "Positive Urgency";

    data.resp = get_resp(data, data.reverse);
      
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
};


var Question11 = {
  type: jsPsychSurveyLikert,
    questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 12/21:\nI finish what I start.</p>",
    labels: scale_1,
    required: true
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 11;
    data.reverse = 0;
    data.factor = "Perseverance";

    data.resp = get_resp(data, data.reverse);
      
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
};

var Question12 = {
  type: jsPsychSurveyLikert,
    questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 13/21:\nI tend to value and follow a rational, 'sensible' approach to things.</p>",
    labels: scale_1,
    required: true
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 12;
    data.reverse = 0;
    data.factor = "Premeditation";

    data.resp = get_resp(data, data.reverse);
      
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
};

var Question13 = {
  type: jsPsychSurveyLikert,
    questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 14/21:\nWhen I am upset I often act without thinking.</p>",
    labels: scale_1,
    required: true
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 13;
    data.reverse = 1;
    data.factor = "Negative Urgency";

    data.resp = get_resp(data, data.reverse);
      
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
};

var Question14 = {
  type: jsPsychSurveyLikert,
    questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 15/21:\nI welcome new and exciting experiences and sensations, even if they are a little frightening and unconventional.</p>",
    labels: scale_1,
    required: true
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 14;
    data.reverse = 1;
    data.factor = "Sensation Seeking";

    data.resp = get_resp(data, data.reverse);
      
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
};

var Question15 = {
  type: jsPsychSurveyLikert,
    questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 16/21:\nWhen I feel rejected, I will often say things that I later regret.</p>",
    labels: scale_1,
    required: true
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 15;
    data.reverse = 1;
    data.factor = "Negative Urgency";

    data.resp = get_resp(data, data.reverse);
      
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
};

var Question16 = {
  type: jsPsychSurveyLikert,
    questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 17/21:\nI would like to learn to fly an airplane.</p>",
    labels: scale_1,
    required: true
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 16;
    data.reverse = 1;
    data.factor = "Sensation Seeking";

    data.resp = get_resp(data, data.reverse);
      
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
};

var Question17 = {
  type: jsPsychSurveyLikert,
    questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 18/21:\nOthers are shocked or worried about the things I do when I am feeling very excited.</p>",
    labels: scale_1,
    required: true
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 17;
    data.reverse = 1;
    data.factor = "Positive Urgency";

    data.resp = get_resp(data, data.reverse);
      
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
};

var Question18 = {
  type: jsPsychSurveyLikert,
    questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 19/21:\nI would enjoy the sensation of skiing very fast down a high mountain slope.</p>",
    labels: scale_1,
    required: true
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 18;
    data.reverse = 1;
    data.factor = "Sensation Seeking";

    data.resp = get_resp(data, data.reverse);
      
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
};

var Question19 = {
  type: jsPsychSurveyLikert,
    questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 20/21:\nI usually think carefully before doing anything.</p>",
    labels: scale_1,
    required: true
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 19;
    data.reverse = 0;
    data.factor = "Premeditation";

    data.resp = get_resp(data, data.reverse);
      
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
};

var Question20 = {
  type: jsPsychSurveyLikert,
    questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 21/21:\nI tend to act without thinking when I am really excited.</p>",
    labels: scale_1,
    required: true
  }, ],
  on_finish: function(data) {
    data.task = 'UPPSP';
    data.question_number = 20;
    data.reverse = 1;
    data.factor = "Positive Urgency";

    data.resp = get_resp(data, data.reverse);
      
    // write data
    var data_row = data.subjID + ',' + 'UPPSP' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
};


var UPPSP_items = [commitment_check, Question1, Question2, Question3, Question4, Question5, Question6, Question7, Question8, Question9, Question10, Question11, Question12, Question13, Question14, Question15, Question16, Question17, Question18, Question19, Question20];

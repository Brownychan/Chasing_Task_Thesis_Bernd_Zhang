
var chasing_question1 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 1/15:\n<strong>After Winning Heavily</strong>, I think I would <em>like</em> to continue betting.</p>",
    labels: ['Occasionally', 'Sometimes', 'Often', 'Very Often', 'Almost Always'],
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'Chasing';
    data.question_number = 1;
    data.factor = "win";
      
    data.resp = data.response.Q0;
    
    // write data
    var data_row = data.subjID + ',' + 'chasing' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
}

var chasing_question2 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 2/15:\nAfter Winning Heavily, I would feel an <em>urge</em> to continue betting.</p>",
    labels: ['Occasionally', 'Sometimes', 'Often', 'Very Often', 'Almost Always'],
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'Chasing';
    data.question_number = 2;
    data.factor = "win";
    
    data.resp = data.response.Q0;
    
    // write data
    var data_row = data.subjID + ',' + 'chasing' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
}

var chasing_question3 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 3/15:\nAfter Winning Heavily, I would continue betting.</p>",
    labels: ['Occasionally', 'Sometimes', 'Often', 'Very Often', 'Almost Always'],
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'Chasing';
    data.question_number = 3;
    data.factor = "win";
    
    data.resp = data.response.Q0;
    
    // write data
    var data_row = data.subjID + ',' + 'chasing' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
}

var chasing_question4 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 4/15:\nAfter Winning Heavily, I think I would <em>like</em> to increase the size of my bets.</p>",
    labels: ['Occasionally', 'Sometimes', 'Often', 'Very Often', 'Almost Always'],
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'Chasing';
    data.question_number = 4;
    data.factor = "win";
    
    data.resp = data.response.Q0;
    
    // write data
    var data_row = data.subjID + ',' + 'chasing' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
}

var chasing_question5 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 5/15:\nAfter Winning Heavily, I would feel an <em>urge</em> to increase the size of my bets.</p>",
    labels: ['Occasionally', 'Sometimes', 'Often', 'Very Often', 'Almost Always'],
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'Chasing';
    data.question_number = 5;
    data.factor = "win";
    
    data.resp = data.response.Q0;
    
    // write data
    var data_row = data.subjID + ',' + 'chasing' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
}

var chasing_question6 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 6/15:\nAfter Winning Heavily, I would increase the size of my bets.</p>",
    labels: ['Occasionally', 'Sometimes', 'Often', 'Very Often', 'Almost Always'],
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'Chasing';
    data.question_number = 6;
    data.factor = "win";
    
    data.resp = data.response.Q0;
    
    // write data
    var data_row = data.subjID + ',' + 'chasing' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
}


var chasing_question7 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 7/15:\n<strong>After Losing Heavily</strong>, I think I would <em>like</em> to continue betting.</p>",
    labels: ['Occasionally', 'Sometimes', 'Often', 'Very Often', 'Almost Always'],
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'Chasing';
    data.question_number = 7;
    data.factor = "loss";
    
    data.resp = data.response.Q0;
    
    // write data
    var data_row = data.subjID + ',' + 'chasing' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
}

var chasing_question8 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 8/15:\nAfter Losing Heavily, I would feel an <em>urge</em> to continue betting.</p>",
    labels: ['Occasionally', 'Sometimes', 'Often', 'Very Often', 'Almost Always'],
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'Chasing';
    data.question_number = 8;
    data.factor = "loss";
    
    data.resp = data.response.Q0;
    
    // write data
    var data_row = data.subjID + ',' + 'chasing' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
}


var chasing_check = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 9/15:\nI read the questions before answering them in the survey so far.</p>",
    labels: ['Occasionally', 'Sometimes', 'Often', 'Very Often', 'Almost Always'],
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'Chasing';
    data.question_number = 1;
    data.factor = "check";
      
    data.resp = data.response.Q0;
    
    // write data
    var data_row = data.subjID + ',' + 'chasing' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
}


var chasing_question9 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 10/15:\nAfter Losing Heavily, I would continue betting.</p>",
    labels: ['Occasionally', 'Sometimes', 'Often', 'Very Often', 'Almost Always'],
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'Chasing';
    data.question_number = 9;
    data.factor = "loss";
    
    data.resp = data.response.Q0;
    
    // write data
    var data_row = data.subjID + ',' + 'chasing' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
}

var chasing_question10 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 11/15:\nAfter Losing Heavily, I think I would <em>like</em> to increase the size of my bets.</p>",
    labels: ['Occasionally', 'Sometimes', 'Often', 'Very Often', 'Almost Always'],
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'Chasing';
    data.question_number = 10;
    data.factor = "loss";
    
    data.resp = data.response.Q0;
    
    // write data
    var data_row = data.subjID + ',' + 'chasing' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
}

var chasing_question11 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 12/15:\nAfter Losing Heavily, I would feel an <em>urge</em> to increase the size of my bets.</p>",
    labels: ['Occasionally', 'Sometimes', 'Often', 'Very Often', 'Almost Always'],
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'Chasing';
    data.question_number = 11;
    data.factor = "loss";
    
    data.resp = data.response.Q0;
    
    // write data
    var data_row = data.subjID + ',' + 'chasing' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
}

var chasing_question12 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 13/15:\nAfter Losing Heavily, I would increase the size of my bets.</p>",
    labels: ['Occasionally', 'Sometimes', 'Often', 'Very Often', 'Almost Always'],
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'Chasing';
    data.question_number = 12;
    data.factor = "loss";
    
    data.resp = data.response.Q0;
    
    // write data
    var data_row = data.subjID + ',' + 'chasing' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
}

var chasing_question13 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 14/15:\n<strong>After a “Near Miss”</strong>, I would continue betting.</p>",
    labels: ['Occasionally', 'Sometimes', 'Often', 'Very Often', 'Almost Always'],
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'Chasing';
    data.question_number = 13;
    data.factor = "near-miss";
    
    data.resp = data.response.Q0;
    
    // write data
    var data_row = data.subjID + ',' + 'chasing' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
}

var chasing_question14 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 15/15:\nAfter a “Near Miss”, I would increase the size of my bets.</p>",
    labels: ['Occasionally', 'Sometimes', 'Often', 'Very Often', 'Almost Always'],
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'Chasing';
    data.question_number = 14;
    data.factor = "near-miss";
    
    data.resp = data.response.Q0;
    
    // write data
    var data_row = data.subjID + ',' + 'chasing' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
  }
}

var chasing_items = [chasing_question1, chasing_question2, chasing_question3, chasing_question4, chasing_question5, chasing_question6, chasing_question7, chasing_question8, chasing_check, chasing_question9, chasing_question10, chasing_question11, chasing_question12, chasing_question13, chasing_question14];

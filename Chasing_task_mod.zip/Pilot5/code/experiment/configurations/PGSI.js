// gambling frequency
var Question_frequency = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 1/11:\nIn the past 12 months, how often have you gambled (including lottery tickets, scratch cards, casino games such as slot machines, roulette, card games such as blackjack, bingo, sports betting, online gambling etc.)?</p>",
    labels: ['Everyday', 'Once or more per week', 'Once or more per month', 'Less than once per month', 'I have not gambled in the past 12 months', 'I have never gambled in my life'],
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'PGSI';
    data.question_number = 0;
    data.factor = "frequency";
    data.resp = get_resp_PGSI(data, 0);
      
    // write data
    var data_row = data.subjID + ',' + 'frequency' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_PGSI_'+ subjID +'.csv', data_row);
  }
}


// gambling problem
var Question_problem = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 2/11:\nIn the past 12 months, have you sought professional help because of problems related to your gambling?</p>",
    labels: ['Yes', 'No'],
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'PGSI';
    data.question_number = 0;
    data.factor = "problem";
    data.resp = get_resp_PGSI(data, 0);
      
    if(data.resp === 0){
      gambling_prob = true;
    } else{
      gambling_prob = false;
    }  
      
    // write data
    var data_row = data.subjID + ',' + 'problem' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_PGSI_'+ subjID +'.csv', data_row);
  }
}


// function for getting responses from the UPPS-P scale
var get_resp_PGSI = function(data, reverse) {
  
  var resp = data.response.Q0;

  // reverse coding
  if (reverse === 1) {
    resp = 5 - resp;
  };

  return resp;

}

var scale_PGSI = ["Never", "Sometimes", "Most of the time", "Almost always"];

 // PGSI questions
var PGSI_Question1 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 3/11:\nHow often have you bet more than you could afford to lose?</p>",
    labels: scale_PGSI,
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'PGSI';
    data.question_number = 1;
    data.factor = "bet";
    data.resp = get_resp_PGSI(data, 0);
      
    PGSI_score = PGSI_score + data.resp;
      
    // write data
    var data_row = data.subjID + ',' + 'PGSI' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_PGSI_'+ subjID +'.csv', data_row);
  }
}

var PGSI_Question2 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 4/11:\nHow often have you needed to gamble with larger amounts of money to get the same feeling of excitement?</p>",
    labels: scale_PGSI,
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'PGSI';
    data.question_number = 2;
    data.factor = "tolerance";
    data.resp = get_resp_PGSI(data, 0);
      
    PGSI_score = PGSI_score + data.resp;
      
    // write data
    var data_row = data.subjID + ',' + 'PGSI' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_PGSI_'+ subjID +'.csv', data_row);
  }
}

var PGSI_Question3 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 5/11:\nHow often have you gone back another day to try to win back the money you lost?</p>",
    labels: scale_PGSI,
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'PGSI';
    data.question_number = 3;
    data.factor = "chase";
    data.resp = get_resp_PGSI(data, 0);
      
    PGSI_score = PGSI_score + data.resp;
      
    // write data
    var data_row = data.subjID + ',' + 'PGSI' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_PGSI_'+ subjID +'.csv', data_row);
  }
}

var PGSI_Question4 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 6/11:\nHow often have you borrowed money or sold anything to get money to gamble?</p>",
    labels: scale_PGSI,
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'PGSI';
    data.question_number = 4;
    data.factor = "borrowed";
    data.resp = get_resp_PGSI(data, 0);
      
    PGSI_score = PGSI_score + data.resp;
      
    // write data
    var data_row = data.subjID + ',' + 'PGSI' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_PGSI_'+ subjID +'.csv', data_row);
  }
}

var PGSI_Question5 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 7/11:\nHow often have you felt you might have a problem with gambling?</p>",
    labels: scale_PGSI,
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'PGSI';
    data.question_number = 5;
    data.factor = "felt-problem";
    data.resp = get_resp_PGSI(data, 0);
      
    PGSI_score = PGSI_score + data.resp;
      
    // write data
    var data_row = data.subjID + ',' + 'PGSI' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_PGSI_'+ subjID +'.csv', data_row);
  }
}


var PGSI_Question6 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 8/11:\nHow often have people criticized your betting or told you that you had a gambling problem, regardless of whether or not you thought it was true?</p>",
    labels: scale_PGSI,
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'PGSI';
    data.question_number = 6;
    data.factor = "criticized";
    data.resp = get_resp_PGSI(data, 0);
      
    PGSI_score = PGSI_score + data.resp;
      
    // write data
    var data_row = data.subjID + ',' + 'PGSI' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_PGSI_'+ subjID +'.csv', data_row);
  }
}

var PGSI_Question7 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 9/11:\nHow often have you felt guilty about the way you gamble or what happens when you gamble?</p>",
    labels: scale_PGSI,
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'PGSI';
    data.question_number = 7;
    data.factor = "felt-guilty";
    data.resp = get_resp_PGSI(data, 0);
      
    PGSI_score = PGSI_score + data.resp;
      
    // write data
    var data_row = data.subjID + ',' + 'PGSI' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_PGSI_'+ subjID +'.csv', data_row);
  }
}


var PGSI_Question8 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 10/11:\nHow often has your gambling caused you any health problems, including stress or anxiety?</p>",
    labels: scale_PGSI,
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'PGSI';
    data.question_number = 8;
    data.factor = "health-problem";
    data.resp = get_resp_PGSI(data, 0);
      
    PGSI_score = PGSI_score + data.resp;
      
    // write data
    var data_row = data.subjID + ',' + 'PGSI' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_PGSI_'+ subjID +'.csv', data_row);
  }
}

var PGSI_Question9 = {
  type: jsPsychSurveyLikert,
  questions: [{
    prompt: "<p style = 'font-size:20px;'>Q 11/11:\nHow often has your gambling caused any financial problems for you or your household?</p>",
    labels: scale_PGSI,
    required: true,
  }, ],
  on_finish: function(data) {
    data.task = 'PGSI';
    data.question_number = 9;
    data.factor = "financial-problem";
    data.resp = get_resp_PGSI(data, 0);
      
    PGSI_score = PGSI_score + data.resp;
      
    // write data
    var data_row = data.subjID + ',' + 'PGSI' + ',' + data.question_number + ',' + data.factor + ',' +
        data.resp + ',' + data.rt + '\n';
    
    appendData('Chasing_PGSI_'+ subjID +'.csv', data_row);
  }
}



var PGSI_items = [Question_frequency, Question_problem, PGSI_Question1, PGSI_Question2, PGSI_Question3, PGSI_Question4, PGSI_Question5, PGSI_Question6, PGSI_Question7, PGSI_Question8, PGSI_Question9];

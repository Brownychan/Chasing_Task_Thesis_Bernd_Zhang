// function for getting responses from the UPPS-P questionnaire
var get_resp = function(data, reverse) {
    var resp = data.response.Q0 + 1;// javaScript uses 0-based indexing. Change into 1-based indexing
    console.log("Reverse value received:", reverse);  
    // reverse coding
    if (Number(data.reverse) === 1) {
      resp = 5 - resp;
    };
    console.log("Calculated resp:", resp);  
    return resp;
  
  }
  
  var scale_1 = ["Rarely/Never", "Occasionally", "Often", "Almost Always/Always"];
  var scale_1_reverse = ["Almost Always/Always", "Often", "Occasionally", "Rarely/Never"];
  // questions
  var question_one = {
    type: jsPsychSurveyLikert,
    questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 1/30:\nI plan tasks carefully.</p>",
      labels: scale_1_reverse,
      required: true,
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 1;
      data.reverse = 1;
      data.factor = "Planning";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  }
  
  
  var question_two = {
    type: jsPsychSurveyLikert,
    questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 2/30:\nI do things without thinking.</p>",
      labels: scale_1,
      required: true,
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 2;
      data.reverse = 0;
      data.factor = "Motor";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  }
  
  var question_three = {
    type: jsPsychSurveyLikert,
    questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 3/30:\nI make-up my mind quickly.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 3;
      data.reverse = 0;
      data.factor = "Motor";
  
      data.resp = get_resp(data, data.reverse);
      
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);  
    }
  };
  
  var question_four = {
    type: jsPsychSurveyLikert,
    questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 4/30:\nI am happy-go-lucky.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 4;
      data.reverse = 0;
      data.factor = "Motor";
  
      data.resp = get_resp(data, data.reverse);
      
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };
  
  var question_five = {
    type: jsPsychSurveyLikert,
    questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 5/30:\nI don't 'pay attention'.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 5;
      data.reverse = 0;
      data.factor = "Attentional";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };
  
  var question_six = {
    type: jsPsychSurveyLikert,
    questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 6/30:\nI have 'racing' thoughts?.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 6;
      data.reverse = 0;
      data.factor = "Attentional";
  
      data.resp = get_resp(data, data.reverse);
      
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };
  
  
  var question_seven = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 7/30:\nI plan trips well ahead of time.</p>",
      labels: scale_1_reverse,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 7;
      data.reverse = 1;
      data.factor = "Planning";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };
  
  
  var question_eigth = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 8/30:\nI am self controlled.</p>",
      labels: scale_1_reverse,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 8;
      data.reverse = 1;
      data.factor = "Planning";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };
  
  var question_nine = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 9/30:\nI concentrate easily.</p>",
      labels: scale_1_reverse,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 9;
      data.reverse = 1;
      data.factor = "Attentional";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };
  
  var question_ten = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 10/30:\nI save regularly.</p>",
      labels: scale_1_reverse,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 10;
      data.reverse = 1;
      data.factor = "Planning";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };
  
  var question_eleven = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 11/30:\nI 'squirm' at plays or lectures.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 11;
      data.reverse = 0;
      data.factor = "Attentional";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };
  
  
  var question_twelve = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 12/30:\nI am a careful thinker.</p>",
      labels: scale_1_reverse,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 12;
      data.reverse = 1;
      data.factor = "Planning";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };
  
  var question_thirteen = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 13/30:\nI plan for job security.</p>",
      labels: scale_1_reverse,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 13;
      data.reverse = 1;
      data.factor = "Planning";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };
  
  var question_fourteen = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 14/30:\nI say things without thinking.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 14;
      data.reverse = 0;
      data.factor = "Planning";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };
  
  var question_fifteen = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 15/30:\nI like to think about complex problems.</p>",
      labels: scale_1_reverse,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 15;
      data.reverse = 1;
      data.factor = "Planning";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };
  
  var question_sixteen = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 16/30:\nI change jobs.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 16;
      data.reverse = 0;
      data.factor = "Motor";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };
  
  var question_seventeen = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 17/30:\nI act 'on impulse'.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 17;
      data.reverse = 0;
      data.factor = "Motor";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };
  
  var question_eighteen = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 18/30:\nI am easily bored when solving thought problems.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 18;
      data.reverse = 0;
      data.factor = "Planning";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };
  
  var question_nineteen = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 19/30:\nI act on the spur of the moment.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 19;
      data.reverse = 0;
      data.factor = "Motor";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };
  
  var question_twenty = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 20/30:\nI am a steady thinker.</p>",
      labels: scale_1_reverse,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 20;
      data.reverse = 1;
      data.factor = "Attentional";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };
  
  var question_twenty_one = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 21/30:\nI change residences.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 21;
      data.reverse = 0;
      data.factor = "Motor";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };
  
  var question_twenty_two = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 22/30:\nI buy things on impulse.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 22;
      data.reverse = 0;
      data.factor = "Motor";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };

  var question_twenty_three = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 23/30:\nI can think only about one thing at a time.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 23;
      data.reverse = 0;
      data.factor = "Motor";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };

  var question_twenty_four = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 24/30:\nI change hobbies.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 24;
      data.reverse = 0;
      data.factor = "Attentional";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };

  var question_twenty_five = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 25/30:\nI spend or charge more than I earn.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 25;
      data.reverse = 0;
      data.factor = "Motor";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };

  var question_twenty_six = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 26/30:\nI often have extraneous thoughts when thinking.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 26;
      data.reverse = 0;
      data.factor = "Attentional";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };

  var question_twenty_seven = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 27/30:\nI am more interested in the present than in the future.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 27;
      data.reverse = 0;
      data.factor = "Planning";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };

  var question_twenty_eight = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 28/30:\nI am restless at the theater or lectures.</p>",
      labels: scale_1,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 28;
      data.reverse = 0;
      data.factor = "Attentional";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };

  var question_twenty_nine = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 29/30:\nI like puzzles.</p>",
      labels: scale_1_reverse,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 29;
      data.reverse = 1;
      data.factor = "Planning";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };

  var question_thirty = {
    type: jsPsychSurveyLikert,
      questions: [{
      prompt: "<p style = 'font-size:20px;'>Q 30/30:\nI am future oriented.</p>",
      labels: scale_1_reverse,
      required: true
    }, ],
    on_finish: function(data) {
      data.task = 'BIS';
      data.question_number = 30;
      data.reverse = 1;
      data.factor = "Motor";
  
      data.resp = get_resp(data, data.reverse);
        
      // write data
      var data_row = data.subjID + ',' + 'BIS' + ',' + data.question_number + ',' + data.factor + ',' +
          data.resp + ',' + data.rt + '\n';
      
      appendData('Chasing_questionnaire_'+ subjID +'.csv', data_row);
    }
  };

  var BIS_items = [question_one, question_two, question_three, question_four, question_five, question_six, question_seven, question_eigth, question_nine, question_ten, question_eleven, question_twelve, question_thirteen, question_fourteen, question_fifteen, question_sixteen, question_seventeen, question_eighteen, question_nineteen, question_twenty, question_twenty_one, question_twenty_two, question_twenty_three, question_twenty_four, question_twenty_five, question_twenty_six, question_twenty_seven, question_twenty_eight, question_twenty_nine, question_thirty ];
  console.log(BIS_items)
# function to load a csv file, and check if participants restarted
load_raw_file <- function(csv_file){
  
  # load a csv file
  df_tmp <- read_csv(csv_file, col_types = cols(.default = col_character()))
  
  # check if the participant restarted the experiment
  # if yes, the header will be written to the file multiple times
  restart <- "subjectID" %in% df_tmp$subjectID
  
  # add a new column for how many times participants started the exp
  df_tmp <- df_tmp %>%
    mutate(
      restart_exp = restart,
      exp_attempt = ifelse(subjectID == "subjectID", 1, 0),
      exp_attempt = cumsum(exp_attempt) + 1
    )
  
  return(df_tmp)
}
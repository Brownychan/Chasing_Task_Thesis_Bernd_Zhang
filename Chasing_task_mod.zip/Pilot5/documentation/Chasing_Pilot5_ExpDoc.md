# Experiment Documentation

## Study/experiment information

### Research question:

Continuing and/or intensifying betting after winning or losing in gambling, called win chasing and loss chasing respectively, play important roles in gambling-related harms. In this project, we develop a novel "Chasing" paradigm that allows the simultaneous examination of both phenomena.

### Experiment context:

-	Code: Chasing
-	Who: Zhang Chen
-	Where: online study via Prolific.co
-	Credit/paid: Paid
-	When:November 2023

### Brief description of method (provide all info required to understand the headers):

Participants first report their age, gender, and nationality. They are then asked how frequently they have gambled in the past year, whether they sought professional help due to their gambling problem in the past year, and fill out the Problem Gambling Severity Index (PGSI). To reduce the potential risk that this study may trigger cravings for gambling in some participants, those who have sought professional help due to their gambling problem or have a PGSI score of 7 or higher are asked to end the experiment.

The remaining participants then receive the instructions for the ‘chasing’ task and get a few practice trials to familiarize themselves with the task. They then receive a quiz to test their understanding of the task. The quiz consists of 12 questions. For each question, participants are asked to imagine that they have received a certain initial amount and a certain spinning wheel and have decided to either spin it or not. They need to answer what will happen after their decision, from a list of 4 possible answers. Participants need to answer at least 9 questions correctly to pass the quiz. Those who fail to pass the quiz are asked to end the experiment.

Those who pass the quiz receive 1.6 British pounds as their initial bonus and proceed to the ‘chasing’ task. Participants press the space bar to initiate a new round. They are then presented with two cards, with a number shown above the cards. The number indicates the amount of money that they may win or lose. Participants press the F or the J key to turn over the left or the right card. If the turned card has a ‘+’ sign, they win the amount of money that is shown. If the turned card has a ‘-’ sign, they lose the amount of money that is shown.
 
The game then proceeds to the ‘chasing’ phase, which offers participants a chance to chase their initial wins and losses. They are shown a spinning wheel, which offers a 50% chance of getting a ‘x0’ and a 50% chance of getting a ‘x2’. If they get a ‘x2’, they can double their initial win or loss amount, whereas a ‘x0’ resets the outcome to 0. Participants need to decide whether they want to spin the wheel or not, by pressing either F or J. The assignment of the F and J keys to the spin and not spin decisions is counterbalanced across participants. On half of the trials, participants can spin the wheel at most twice. On the remaining half, they can spin the wheel at most once. The number of times that they can spin the wheel is shown to participants via the number of empty boxes throughout a round. These empty boxes are also used to show the intermediate outcomes within each round to participants. A round ends (1) when participants decide to not chase (i.e., not spin a wheel), (2) when they get a ‘x0’ from the wheel, or (3) when they reach the end of a round.

The ‘chasing’ task consists of 96 experimental trials and 16 catch trials. For the experimental trials, we adopt a 2 (initial outcome, win vs. loss) by 3 (initial amount, 10, 20 vs. 40 British pence) and 2 (number of chasing opportunities, 1 vs. 2) design, with 8 trials in each cell. The probability of getting ‘x0’ or ‘x2’ after spinning a wheel is 50%/50%. We also include catch trials, in which the wheel either offers a 100% chance of getting ‘x0’, or a 100% chance of getting ‘x2’. For the catch trials, we use a 2 (initial outcome, win vs. loss) by 2 (number of chasing opportunities, 1 vs. 2) by 2 (wheel type, 100% ‘x0’ vs. 100% ‘x2’) design, with 2 trials in each cell. The initial amount (10, 20 or 40 pence) is determined randomly for each catch trial. The 112 trials are divided into 4 blocks, with each block containing between 3 and 7 catch trials. After each block, participants take a short break of at least 10 seconds.

After the ‘chasing’ task, participants then fill out the short English version of the UPPS-P impulsive behavior scale (Cyders, Littlefield, Coffey, & Karyadi, 2014), and a questionnaire on chasing behavior in gambling (Connor, & Dickerson, 2003). We add two attention check items into the two questionnaires. First, the very first item in the UPPS-P scale states that “I will read the questions carefully before answering them in this survey.”, and participants need to choose from "Agree strongly", "Agree some", "Disagree some", "Disagree strongly". In the questionnaire on chasing, one question states that “I read the questions before answering them in the survey so far.”, and participants need to choose from 'Occasionally', 'Sometimes', 'Often', 'Very Often', 'Almost Always'.

At the end of the experiment, one trial from the ‘chasing’ task is randomly selected. The money participants win or lose on this randomly selected trial is added to or subtracted from the initial bonus and determines the final bonus. Participants are debriefed, thanked, and paid.

### Apparatus and calibration:

- Apparatus: PC, jsPsych
- Calibration protocol: None

### Data file information:

File Types: Behavioural data files only (CSV).

### Variable labels (headers) and variable coding:

#### Demographic information (Chasing_demo_X.csv)

- subjectID = anonymous subject ID after data collection.
- age = self-reported age of participant.
- gender = self-reported gender of participant. Four levels: male, female, non-binary, or I don't want to say
- nationality = self-reported nationality of participant.
- exp_start_time = time when participant started the experiment.
- browser = which web browser participant used to do the experiment.
- browser_version = the version number of the used browser.
- win_width = the width of the screen used by participant, in pixels.
- win_height = the height of the screen used by participant, in pixels.
- vsync_rate = an estimate of the refresh rate of the screen, in frames per second.
- os = the operating system used.
- exp_end_time = time when participant finished the experiment.
- final_balance = the number of points in participants' balance.
- bonus = extra bonus participants received, in British pound.
- pass_PGSI_check = whether participants pass the initial PGSI check or not. true = pass, false = not pass.
- pass_comprehension_check = whether participants pass the quiz or not. true = pass, false = not pass. 

#### PGSI (Chasing_PGSI_X.csv)
 
- subjectID = anonymous subject ID after data collection.
- questionnaire = which questionnaire it is. frequency (gambling frequency), problem (gambling problem), PGSI.
- item_number = item number within each questionnaire.
- factor = different factors within PGSI.
- response = response given for each question. For the question on gambling frequency, participants are asked 'In the past 12 months, how often have you gambled (including lottery tickets, scratch cards, casino games such as slot machines, roulette, card games such as blackjack, bingo, sports betting, online gambling etc.)?' 0 = Everyday, 1 = Once or more per week, 2 = Once or more per month, 3 = Less than once per month, 4 = I have not gambled in the past 12 months, 5 = I have never gambled in my life. For the question on gambling problem, participants are asked 'In the past 12 months, have you sought professional help because of problems related to your gambling?' 0 = Yes, 1 = No. For the PGSI, 0 = Never, 1 = Sometimes, 2 = Most of the time, 3 = Almost always.
- RT = the response time for answering each question, in milliseconds. 


#### Comprehension check (Chasing_comprehension_X.csv)

- subjectID = anonymous subject ID after data collection.
- attempt = which attempt it is. In this pilot, participants can only attempt once.
- trial_number = trial number in each attempt, from 1 to 12.
- outcome = the initial outcome in the question, W = win, L= Loss.
- trial_type = the type of wheel being shown. catch0 = the wheel offers 100% x0; catch2 = the wheel offers 100% x2; exp = the wheel offers 50% x0, and 50% x2.
- choice = the choice made in the question, spin or not spin.
- resp = answer provided by participants. 1 = You will for sure get 0 pence. 2 = You will for sure win (lose) 50 pence in total. 3 = You will for sure win (lose) 100 pence in total. 4 = You have a 50% chance to get 0 pence, and a 50% chance to win (lose) 100 pence in total.
- rt = response time for answering each question, in milliseconds.
- correct_ans = the correct answer.
- correct = whether the answer is correct (1) or not (0).

#### Data from the "Chasing" game (Chasing_main_X.csv)

- subjectID = anonymous subject ID after data collection.
- wheel_counterbalance = the assignment of F and J keys into continue playing or quit decisions, counterbalanced across participants. f-play-j-quit or f-quit-j-play.
- block_type = practice or experimental block.
- block_number = block number. One practice block and One experimental block.
- trial_number = trial number within each block.
- trial_type = trial type, catch or experimental.
- outcome = the initial outcome in a trial, W = win, L = loss.
- amount = the initial amount, in British pence.
- total_wheel = the total number of wheels within a round, 1 or 2.
- wheel1 = the predetermined outcome of the first wheel if being spun, 0 or 2.
- wheel2 = the predetermined outcome of the second wheel if being spun, 0 or 2.
- resp_count = response number within each trial (round). One trial contains 3 or 4 responses.
- phase = the different phases within one round, 'start', 'card' or 'wheel'.
- key = which key is pressed, space, f or j.
- RT = the reaction time of key press, in milliseconds.
- choice = the choice that each key press stands for. For the 'start' phase, only the space bar is allowed. For the 'card' phase, f = 'left'
 and j = 'right'. For the 'wheel' phase, the choice is either 'play' or 'quit'.
- current_wheel = the outcome of the current wheel, 0 or 2. For the 'start' and 'card' phase, this variable is always 0.
- current_outcome = the current outcome at each stage within a trial.
- wheel_rotation = the degree o f rotation after spinning the wheel.
 
#### Data from the questionnaires (Chasing_questionnaire_X.csv)
 
- subjectID = anonymous subject ID after data collection.
- questionnaire = which questionnaire it is. UPPSP or chasing questionaire.
- item_number = item number within each questionnaire.
- factor = different factors within each questionnaire.
- response = response given for each question. For the UPPSP, 1 = Agree strongly, 2 = Agree some, 3 = Disagree some, 4 = Disagree strongly. Items that require reverse coding are already reversed, so that a higher score indicates more impulsivity. For the chasing questionnaire, 0 = Occasionally, 1 = Sometimes, 2 = Often, 3 = Very Often, 4 = Almost Always.
- RT = the response time for answering each question, in milliseconds. 

 
### Quality control measures
None.

### Additional documents
None.
